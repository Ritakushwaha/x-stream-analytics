# twitter-flink-project
Sample project for twitter streaming using flink
